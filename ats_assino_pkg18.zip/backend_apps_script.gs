/*** ATS ASSINO — Backend v2 (Google Apps Script + Google Sheets) ***
 * Guarda o estado do ATS quebrado em vários pedaços (chunks), porque uma
 * célula do Sheets guarda no máximo ~50.000 caracteres. Assim a base grande
 * (centenas de candidatos) grava sem erro.
 *
 * Deploy: Implantar > Nova implantação > App da Web >
 *   Executar como: Eu | Quem pode acessar: Qualquer pessoa.
 * A cada alteração no código: Gerenciar implantações > Nova versão.
 */
var SHEET_NAME = 'ats_data';
var CHUNK = 45000; // margem segura abaixo do limite de 50.000 por célula

function _sheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) { sh = ss.insertSheet(SHEET_NAME); }
  return sh;
}

// Grava uma string longa dividida em várias linhas da coluna A
function _writeAll(str) {
  var sh = _sheet();
  sh.clear();
  var parts = [];
  for (var i = 0; i < str.length; i += CHUNK) {
    parts.push([str.substring(i, i + CHUNK)]);
  }
  if (parts.length === 0) parts.push(['']);
  sh.getRange(1, 1, parts.length, 1).setValues(parts);
}

// Lê e junta todas as linhas da coluna A
function _readAll() {
  var sh = _sheet();
  var last = sh.getLastRow();
  if (last < 1) return '';
  var vals = sh.getRange(1, 1, last, 1).getValues();
  var str = '';
  for (var i = 0; i < vals.length; i++) { str += vals[i][0]; }
  return str;
}

// Carregar dados (GET ?action=load)
function doGet(e) {
  var out = { ok: true, backend: 'v5-pre', data: null };
  try {
    var raw = _readAll();
    out.data = raw ? JSON.parse(raw) : null;
  } catch (err) { out.ok = false; out.error = String(err); }
  return ContentService.createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}

// Salvar dados (POST body: {action:'save', data:{...}}) ou DISC (action:'disc')
function doPost(e) {
  var out = { ok: true };
  try {
    var body = JSON.parse(e.postData.contents);
    if (body.action === 'save') {
      _writeAll(JSON.stringify(body.data));
    } else if (body.action === 'vagareq') {
      var raw0 = _readAll();
      var d0 = raw0 ? JSON.parse(raw0) : {};
      d0._vagaInbox = d0._vagaInbox || [];
      d0._vagaInbox.push(body.data || {});
      _writeAll(JSON.stringify(d0));
    } else if (body.action === 'pretriagem') {
      var rawt = _readAll();
      var dt = rawt ? JSON.parse(rawt) : {};
      dt._triagemInbox = dt._triagemInbox || [];
      dt._triagemInbox.push(body.data || {});
      _writeAll(JSON.stringify(dt));
    } else if (body.action === 'candidatura') {
      var rawc = _readAll();
      var dc = rawc ? JSON.parse(rawc) : {};
      dc._candInbox = dc._candInbox || [];
      dc._candInbox.push(body.data || {});
      _writeAll(JSON.stringify(dc));
    } else if (body.action === 'disc') {
      var raw = _readAll();
      var data = raw ? JSON.parse(raw) : { candidates: [] };
      var p = body.data || {};
      var c = (data.candidates || []).find(function (x) { return x.id === p.cid; });
      if (c) { c.disc = { D: p.D || 0, I: p.I || 0, S: p.S || 0, C: p.C || 0, done: true }; }
      else { data._discInbox = data._discInbox || []; data._discInbox.push(p); }
      _writeAll(JSON.stringify(data));
    }
  } catch (err) { out.ok = false; out.error = String(err); }
  return ContentService.createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}
